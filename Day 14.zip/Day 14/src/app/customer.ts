export class Customer {
    id: number;
    name: string;
    age: number;
    mobile_no: string;
    active: boolean;
}
