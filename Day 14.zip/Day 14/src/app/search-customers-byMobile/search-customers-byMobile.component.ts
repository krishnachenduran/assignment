import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'search-customers-byMobile',
  templateUrl: './search-customers-byMobile.component.html',
})
export class SearchCustomersByMobileComponent implements OnInit {

  mobile_no: string;
  customers: Customer[];

  constructor(private dataService: CustomerService) { }

  ngOnInit() {
    this.mobile_no =null;
  }

  private searchCustomers() {
    this.dataService.getCustomersByMobile(this.mobile_no)
      .subscribe(customers => this.customers = customers);
  }

  onSubmit() {
    this.searchCustomers();
  }
}
