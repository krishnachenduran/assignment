import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <div>
      <my-base></my-base>
      <hr />
      <my-inherited></my-inherited>
      <hr />
      <my-inherited1></my-inherited1>
    </div>
  `
})
export class AppComponent { }