import { Component } from '@angular/core';
import { BaseComponent } from './base.component';

@Component({
  selector : 'my-inherited1',
  template: `
  <div style='background-color: yellow'>
     {{val}}
  </div>
`
})
export class DerivedComponent1 extends BaseComponent {}