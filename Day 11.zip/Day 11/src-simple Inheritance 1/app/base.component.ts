import { Component, Input  } from '@angular/core';

@Component({
  selector : 'my-base',
  template: `
    <div style='background-color: #ff0000'>
       {{val}}
    </div>
  `
})
export class BaseComponent {
  val: string = 'Some Sample String';
}